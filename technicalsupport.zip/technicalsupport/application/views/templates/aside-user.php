<style>
    .aside{
    margin-top: 5%;
    margin-bottom: 7%;
    
}
.b1{
    border-top-left-radius: 10px;
}
.b4{
    border-bottom-left-radius: 10px;
}

.b1,.b2,.b3,.b5,.b4{
    color:#423E37;
    border:center solid 1px;
    background-color: #ffffff;
    width:100%;
    font-size: 1.3rem;

}
.b1:hover,.b2:hover,.b3:hover,.b4:hover,.b5:hover{
    background-color: #EEEEEE ;
}
</style>
<div class="container-fluid" style="margin-top: 40px;">
        <div class="row">
        <div class="col-3">

<aside>
   
                <div class="aside">
                    <button class="b1" type="button">الشـكاوى</button>
                    <br>
                    <button class="b2" type="button">الرسـائل</button>
                    <br>
                    <a href="<?php echo base_url().'Ticket/view' ?>"><button class="b5" type="button">شكوى جديدة</button></a>
                    <br>
                    <button class="b3" type="button">الشـكاوى المحلولة</button>
                    <br>
                    <button class="b4" type="button">الأنظمة</button>
                </div>
</aside>
</div>