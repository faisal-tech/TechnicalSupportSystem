<footer class="footer">
    <div id="footer">
        <div class="row">
            <div class="col col-lg-3 col-md-6 col-sm-12">

                <div class="logos">

                    <div>
                        <img class="f-logo1" src="https://www.pp.gov.sa/themes/ppgov_new_theme/assets/img/f-logo1.svg" alt="">
                        <img class="f-logo2" src="https://www.pp.gov.sa/themes/ppgov_new_theme/assets/img/f-logo2.svg" alt="">
                    </div>
                    <div class="social">
                        <i class="social2 fab fa-youtube"></i>
                        <i class="social1 fab fa-twitter "></i>
                    </div>
                </div>
            </div>




            <div class="col col-lg-3 col-md-6 col-sm-12">

                <h3>روابط مهمة</h3>

                <div class="links">
                    <a class="gov" href="https://www.my.gov.sa/wps/portal/snp/main"><img src="https://www.pp.gov.sa/themes/ppgov_new_theme/assets/img/logo-gov.svg" alt=""></a>

                    <br>
                    <a class="job-rules" href=""><img class="job-rules-img" src="https://www.pp.gov.sa/themes/ppgov_new_theme/assets/img/job-rules.svg" alt="">قواعد السلوك الوظيفي</a>
                    <br>

                    <a class="king-prize" href=""><img src="https://www.pp.gov.sa/themes/ppgov_new_theme/assets/img/pp3.png" class="king-prize-logo" alt="" height="40px">جائزة الملك عبدالعزيز للجودة<p style="text-align: center;">المستوي البرونزي</p></a>
                </div>


            </div>

            <div class="col col-lg-3 col-md-6 col-sm-12">

                <h3>المركز الإعلامي</h3>

                <div class="footer-links">

                    <a class="links-footer" href="https://www.pp.gov.sa/ar/news">الأخبار</a>
                    <br>
                    <a class="links-footer" href="https://www.pp.gov.sa/ar/events">الفعاليات وورش العمل</a>
                    <br>
                    <a class="links-footer" href="https://www.pp.gov.sa/ar/opendata">البيانات المفتوحة</a>


                </div>

            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">

                <h2>اتصل بنا</h2>

                <div class="footer-links">

                    <a class="links-footer" href="https://www.pp.gov.sa/ar/contact/public_prosecutor">التواصل مع معالي النائب العام</a>
                    <br>
                    <a class="links-footer" href="https://www.pp.gov.sa/ar/contact/public_prosecutor_sectors">التواصل مع القطاعات النيابية</a>
                    <br>
                    <a class="links-footer" href="https://www.pp.gov.sa/ar/contact">استمارة الاتصال</a>


                </div>

            </div>

            <div class="copy-right">
                <div class="copy-right2">
                    <p class="copy-para" style="display:inline;">جميع الحقوق محفوظة النيابة العامة</p>
                    <a class="right-link1" href="https://www.pp.gov.sa/ar/privacy-policy">سياسة الخصوصية</a>
                    <a class="right-link2" href="https://www.pp.gov.sa/ar/terms-of-use">الشروط والأحكام</a>



                </div>
            </div>


        </div>

    </div>
</footer>

</body>

</html>