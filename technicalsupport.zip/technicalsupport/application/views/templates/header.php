<!DOCTYPE html>
<html lang="en">
<style>
    @media (max-width: 990px) {
        .navbar-nav {

            padding-right: 0px;
        }

        ul {
            padding-right: 0px;
        }

        .unline:before {
            visibility: hidden;
        }

    }

    ul {
        display: inline-block;
        margin-right: 50px;

    }


    .nav-item {
        position: relative;
        display: inline-block;
        margin-top: 10px;

        padding-right: 10px;



    }


    .unline:before {

        content: ' ';
        position: absolute;
        height: 3px;
        width: 0;
        background-color: #006D67;
        left: 10px;
        top: 39px;
        transition: all 500ms ease-in-out 0s;

    }

    .unline:hover:before {

        content: ' ';
        position: absolute;
        height: 3px;
        width: 87%;
        background-color: #006D67;
        left: 10px;
        top: 39px;
        transition: all 500ms ease-in-out 0s;

    }
</style>


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/style.css">
    <script type="text/javascript" href="<?php echo base_url()?> assets/index.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">

    <!-- GOOGLE FONTS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600&family=Readex+Pro:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>

    <script rel="stylesheet" charset="utf8" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css"></script>

    <script type="text/javascript" charset="utf8" href="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>


    <script src="https://kit.fontawesome.com/6f3e2b9942.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <title>Technical Support</title>

</head>



<body>
    <header>
        <div class="container-fluid" style="padding-right:0; padding-left: 0;">

            <nav class="navbar nav-menu navbar-expand-lg navbar-light bg-light" id="head">
                <!-- LOGO -->


                <a class="navbar-brand ms-auto head-logo" href="https://www.pp.gov.sa/ar"><img src="<?php echo base_url() . 'images/logo.svg' ?>" height="60px" alt="النيابة العامة"></a>


                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggler" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarToggler">


                    <!-- DROPDOWNS -->


                    <ul class="navbar-nav  ms-auto" style="margin-top:10px;width:70%">
                        <li class="nav-item unline" style="padding-right:0; padding-left:10px;"><a class="nav-link" href="https://www.pp.gov.sa/ar">الرئيسية</a></li>

                        <li class="nav-item dropdown unline"><a class="nav-link dropdown-toggle" href="" id="drop" role="button" data-bs-toggle="dropdown">من نحن</a>
                            <ul class="dropdown-menu" aria-labelledby="drop">
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/node/146">عن النيابة</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/vision-mission">الرؤوية والرسالة</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/word-officials">كلمة المسؤولين</a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown unline"><a class="nav-link dropdown-toggle" href="" id="dropdown" role="button" data-bs-toggle="dropdown">مركز المعرفة</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown">
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/knowledge">مركز المعرفة</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/gallery">المكتبة المرئية</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="hhttps://www.pp.gov.sa/ar/documents-library">مكتبة الوثائق</a></li>
                            </ul>

                        </li>

                        <li class="nav-item dropdown unline"><a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown">الخدمات</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown">
                                <li class="dropdown-item"><a class="nav-link" href="">الاستعلامات الالكترونية</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="">الخدمات الالكترونية</a></li>
                            </ul>
                        </li>


                        <li class="nav-item dropdown unline"><a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown">المركز الإعلامي</a>

                            <ul class="dropdown-menu">
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/news">الأخبار</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/events">الفعاليات وورش العمل</a></li>

                            </ul>
                        </li>

                        <li class="nav-item unline"><a class="nav-link" style="width:130px" href="https://www.pp.gov.sa/ar/documents-library">البيانات المفتوحة</a></li>

                        <li class="nav-item dropdown unline"><a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown">اتصل بنا</a>

                            <ul class="dropdown-menu">
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/documents-library">التواصل مع معالي النائب العام</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/contact/public_prosecutor_sectors">التواصل مع القطاعات النيابية</a></li>
                                <li class="dropdown-item"><a class="nav-link" href="https://www.pp.gov.sa/ar/contact">نموذج الاتصال</a></li>


                            </ul>
                        </li>
                    </ul>
                    <div class="d-flex" style>

                        <ul class="navbar-nav" style='margin:10px 0 0 70px' >
                            <li class="nav-item dropdown user-icon" style="margin-left:20%;">
                                <a class="nav-link dropdown-toggle " id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" href="">
                                    <img src="<?php echo base_url() . 'images/user1-modified.png' ?>" height="40px" alt=""></a>
                                <ul class="dropdown-menu " aria-labelledby="navbarDropdown">
                                    <?php
                                    if (!isset($_SESSION['login'])) {
                                    ?>
                                        <li><a class="dropdown-item" href="<?php echo base_url() . 'Register/view' ?>">تسجيل جديد</a></li>



                            <?php
                                    } else {
                            ?>
                            
                            <li><a class="dropdown-item" href="<?php echo base_url() . 'UserInfo/view' ?>">عرض المعلومات</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="<?php echo base_url() . 'UserInfo/signOut' ?>">تسجيل خروج</a></li>


                    <?php
                                    }
                    ?>
                                            </ul>

                    </li>
                    </ul>

                    </div>



                </div>







            </nav>
        </div>

    </header>