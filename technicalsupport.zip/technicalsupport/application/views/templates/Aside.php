<style>
    .aside {
        margin-top: 5%;
        margin-bottom: 7%;

    }

    .b1 {
        border-top-left-radius: 10px;
    }

    .b4 {
        border-bottom-left-radius: 10px;
    }

    .b1,
    .b2,
    .b3,
    .b4 {
        color: #423E37;
        border: center solid 1px;
        background-color: #ffffff;
        width: 100%;
        font-size: 1.3rem;

    }

    .b1:hover,
    .b2:hover,
    .b3:hover,
    .b4:hover {
        background-color: #EEEEEE;
    }
</style>
<div class="container-fluid" style="margin-top: 40px;">
    <div class="row">
        <div class="col-3">

            <aside>


                <div class="aside">
                    <button class="b1" type="button"><a href="<?php echo base_url() . 'Ticket/view' ?>">رسـالـة جديـدة</a></button>
                    <br>
                </div>
            </aside>
        </div>