<body>

    <div class="Info">
        <table style="text-align:center; font-size:1.25rem" class="table table-striped">
            
                <thead>
                    <th colspan="2">الـبيـانـات</th>
                </thead>
                <tr>
                    <td>
                        الاسـم:
                    </td>
                    <td>
                        <?php echo  $_SESSION['FName'] . " " . $_SESSION['LName']; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        القـسـم:
                    </td>
                    <td>
                        <?php echo  $_SESSION['Department']; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        عدد التذاكر:
                    </td>
                    <td style="padding-right: 40px">
                        <?php echo '    ' . $numTicket["COUNT(ReportUser)"]  // die(var_dump($numTicket)); 
                        ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        الإيميل:
                    </td>
                    <td>
                        <?php echo $_SESSION['Email'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        الصلاحيات:
                    </td>
                    <td>
                        <?php if ($_SESSION['PrivilegeLevel'] === 1) {
                            echo "مشرف";
                        } else {
                            echo "مستخدم";
                        }

                        ?>
                    </td>
                </tr>
            
        </table>
    </div>

</body>