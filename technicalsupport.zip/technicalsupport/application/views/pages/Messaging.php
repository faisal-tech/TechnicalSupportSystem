
<div class="col-7">
    <section>
        <div class="frame" style="background-color: #ffffff;">

            <div class="messaging-frame">
                <div class="Title-in-message">
                    <h4 class="title-message">عنوان المشكلة</h4>
                </div>
                <div class="messaging-box">

                    <!--THIS DIV TO KEEP EACH TEXT IN A ROW -->

                    <!-- THE CONTAIRNER FOR THE TEXT-->
                    <?php
                    // THE FIRST MESSAGE FROM MESSAGE TABLE
                    foreach ($first as $key => $index) { ?>
                        <div class="row">
                            <div class="col" style="margin-bottom:15px">
                            <?php
                            if ($_SESSION['EmployeeNum'] === $index['Admin']) {
                                echo "<div class='sent'>"
                                    . $index['Message'] . "</div>";
                            } else {
                                echo  "<div class='recived'>" . $index['Message'] . "</div>";
                            }
                        }
                            ?>
                            </div>
                        </div>


                        <!-- THE MESSAGES FROM THE COMMUNICATIONS THAT COMES AFTER INITIAL MASSAGE FROM ADMIN -->
                        <?php
                        foreach ($rest as $x => $y) { ?>

                            <?php
                            if ($_SESSION['EmployeeNum'] === $y['Sender']) { ?>

                                <div class='row' style='margin-bottom:15px'>
                                    <div class='col'>
                                        <div class='sent'>
                                            <?php echo $y['Text'];
                                            ?> </div>
                                    </div>
                                </div> <?php
                                    } else { ?>
                                <div class='row' style="margin-bottom:15px">
                                    <div class='col'>
                                        <div class='recived'>
                                            <?php echo $y['Text'];
                                            ?> </div>
                                    </div>
                                </div> <?php
                                    }
                                }
                                        ?>
                </div>
                <div>           <!--THE BUTTON AND TEXT AREA TO SEND TEXT  -->

<form action="<?php echo base_url() . 'Messaging/sendText/' . $message ?>" method="post">
    <div class="row">
        <div class="col col-10">
            <div style="margin-top:17px" class="form-floating mb-3">
                <input style="overflow:scroll;" type="text" name="text" class="form-control" id="floatingInput" placeholder="name@example.com">
                <label style="margin-left:90%" for="floatingInput">تواصل</label>
            </div>
        </div>
        <div class="col-2" style="padding-top:2%">
            <button class="btn btn-primary" style="margin-top:10px" type="submit">ارسال</button>
        </div>
    </div>
</form>
</div>
            </div>


        </div>



</div>
</div>
</section>
</div>
</div>
</div>