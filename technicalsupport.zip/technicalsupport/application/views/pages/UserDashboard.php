
<div class="col col-9">
    <section>

        
        <table id="table_id" class="display" style="margin-bottom: 10%;width:100%">
            <thead>
                <tr>
                    <th>العنوان</th>
                    <th>الوصف</th>
                    <th>الحالة</th>
                    <th>النظام</th>
                    <th>مقدم الدعم</th>
                    <th>التاريخ</th>
                </tr>
            </thead>
            <tbody>

                <?php foreach ($tickets as $index => $value) { ?>

                    <tr>

                        <td>
                            <a href="<?php echo base_url() ?>DisplayTicket/view/<?php echo $value['ReportNum'] ?>">

                                <?php echo $value['Title']; ?>
                            </a>
                        </td>
                        <td>
                            <?php echo $value['Description']; ?>
                        </td>

                        <td>
                            <?php echo $value['Status']; ?>
                        </td>
                        <td>
                            <?php echo $value['System']; ?>
                        </td>
                        <td>
                            <?php //echo $Name; ?>
                        </td>
                        <td>
                            <?php echo $value['date']; ?>
                        </td>


                    </tr>


                <?php };
                ?>

            </tbody>
            <tfoot>
                <tr>
                    <th>العنوان</th>
                    <th>الوصف</th>
                    <th>الحالة</th>
                    <th>النظام</th>
                    <th>المستخدم</th>
                    <th>التاريخ</th>
                </tr>
            </tfoot>
        </table>
        <br>
        </section>

</div>


</div> <!-- row closed div -->
 </div> <!--CONTAINER FLUID CLOSED DIV -->


<script>
    
    $(document).ready(function() {
        $('#table_id').DataTable({

        });
    });
    $(document).ready(function() {
        $('#table').DataTable({

        });
    });
</script>