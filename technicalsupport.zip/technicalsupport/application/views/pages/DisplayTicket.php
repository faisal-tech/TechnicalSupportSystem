<style>
    #myImg {
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }

    #myImg:hover {
        opacity: 0.7;
    }

    /* The Modal (background) */
    .modal {
        display: none;
        /* Hidden by default */
        position: fixed;
        /* Stay in place */
        z-index: 1;
        /* Sit on top */
        padding-top: 100px;
        /* Location of the box */
        left: 0;
        top: 0;
        width: 100%;
        /* Full width */
        height: 100%;
        /* Full height */
        overflow: auto;
        /* Enable scroll if needed */
        background-color: rgb(0, 0, 0);
        /* Fallback color */
        background-color: rgba(0, 0, 0, 0.9);
        /* Black w/ opacity */
    }

    #assign-btn {
        margin-right: 30px;
        background-color: #006D67;
        color: #ffffff;
        width: 120px;
        height: 40px;
        font-size: 19px;
    }

    #assign-btn:hover {
        background-color: #005954;

    }



    /* Modal Content (Image) */
    .modal-content {
        margin: auto;
        display: block;
        width: 80%;
        max-width: 700px;
    }

    /* Caption of Modal Image (Image Text) - Same Width as the Image */
    #caption {
        margin: auto;
        display: block;
        width: 80%;
        max-width: 700px;
        text-align: center;
        color: #ccc;
        padding: 10px 0;
        height: 150px;
    }

    /* Add Animation - Zoom in the Modal */
    .modal-content,
    #caption {
        animation-name: zoom;
        animation-duration: 0.6s;
    }

    @keyframes zoom {
        from {
            transform: scale(0)
        }

        to {
            transform: scale(1)
        }
    }

    /* The Close Button */
    .close {
        position: absolute;
        top: 15px;
        right: 35px;
        color: #f1f1f1;
        font-size: 40px;
        font-weight: bold;
        transition: 0.3s;
    }

    .close:hover,
    .close:focus {
        color: #bbb;
        text-decoration: none;
        cursor: pointer;
    }

    /* 100% Image Width on Smaller Screens */
    @media only screen and (max-width: 700px) {
        .modal-content {
            width: 100%;
        }
    }
</style>
<?php
// die(var_dump($messages));


// FOR TO DEAL WITH THE INDEXES OF THE REPORT LATER.
foreach ($report as $index) {
    $index['Description'];
} ?>




<section>

    <!-- THE START OF THE NAV OF THE REPORT INFO AND THE MESSAGES -->


    <ul class="nav nav-tabs" style="margin-right:6%">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true" style="font-size: 1.2rem;">الشكوى</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false" style="font-size: 1.2rem;">الرسائل</button>
        </li>
    </ul>



    <!-- THE BUTTON OF THE REPORT INFO -->


    <div class="tab-content" id="myTabContent">

        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

            <div class="Ticket-info" style="border:solid ;background-color: #eeeeee; border-radius:3px; padding:1% 3%; height:90%">

                <div class="arrow" style="padding: 3%  3%; ">

                    <!-- TO DECIDE TO WHICH DASHBOARD THE ARROW SHOULD GO BACK TO -->
                    <a <?php if ($_SESSION['PrivilegeLevel'] == 1) { ?> href="<?php echo base_url() . 'AdminDashboard/view' ?>" <?php } else { ?>href="<?php echo base_url() . 'UserDashboard/view';
                                                                                                                                                    } ?>"> <img style="margin-right:10px; margin-top: 10px;" height="30px" src="<?php echo base_url() . 'images/right-arrow.png' ?>"></a>
                </div>
                <div class="row">
                    <!-- THE INFO OF THE USER -->
                    <div class="col col-8" style="padding-right:5%">

                        <div class="row" style="background-color:#ffffff; border-radius: 15px; width:60%;margin-right:4% ">
                            <h4> <?php echo $index['Title'] ?></h4>
                        </div>

                        <div class="row" style="background-color:#fff; border-radius :15px; width:100%; margin-top:10px;">
                            <p>
                                <?php echo $index['Description'] ?>
                            </p>

                        </div>

                    </div>
                    <!-- THE INFO ABOUT THE EMPLOYEE HOW FILES THE REPORT -->
                    <div class="row col col-2" style="margin-right:5%; border-radius:10px; height:40%; width: 15%;">

                        <p>
                            <input type="hidden" id="report_num" name="reportNum" value="<?php echo $index['ReportNum'] ?>">
                            <br>
                            الرقم الوظيفي: <?php echo $index['ReportUser'] ?>
                            <br>
                            النظام: <?php echo $index['System'] ?>
                            <br>
                            التاريخ: <?php echo $index['date'] ?>
                            <br>
                            الحالة: <?php echo $index['Status'] ?>

                        </p>


                        <div style="margin-top:30px">
                            <img id="myImg" src="<?php echo base_url() . 'Uploaded_Image/' . str_replace(' ', '_', $index['image']); ?>" height="100" width="100">
                        </div>
                        <div id="myModal" class="modal">

                            <!-- The Close Button -->
                            <span class="close">&times;</span>

                            <!-- Modal Content (The Image) -->
                            <img class="modal-content" id="img01">

                            <!-- Modal Caption (Image Text) -->
                            <div id="caption"></div>
                        </div>
                        <!-- اغـــلاق الـتـقـريـر -->
                        <?php
                        if (($_SESSION['PrivilegeLevel'] == 1 && $index['ReportAdmin'] !== null) && $index['Status'] !== "مغلق") {
                        ?>
                            <form style="padding-top: 25px;" action="<?php echo base_url() . 'DisplayTicket/changeStatus/' . $index['ReportNum'] ?>">
                                <input style="margin-right:0" type="submit" id="assign-btn" value="إغلاق التذكرة" onclick="disable()">
                            </form>
                        <?php } ?>
                    </div>
                </div>

                <div class="row" style=" margin-right:5%">

                    <!-- DEPENDING ON THE PRIVILEGE THE THE FOLLOWING WILL be SHOWN TO THE USER  -->
                    <?php
                    if ($index['ReportAdmin'] == null) {
                        if ($_SESSION["PrivilegeLevel"] == 1) { ?>
                            <form action="<?php echo base_url() . 'DisplayTicket/assignAdmin/' . $index['ReportNum'] ?>">
                                <button type="submit" id="assign-btn">إستلام التقرير</button>
                            </form>
                        <?php } else {
                        ?>
                            <h5>بإنتظار استلام التقرير من موظف الدعم...</h5>
                        <?php
                        }
                    } else {
                        ?>
                        <div class="row">



                            <div class="col col-10">

                                <div style="margin-top:17px" class="form-floating mb-3">

                                    <input style="overflow:scroll;" type="text" name="text" id="text_sent" class="form-control texty_sent" <?php if ($index['Status'] == 'مغلق') { ?> disabled <?php } ?> id="floatingInput" placeholder="name@example.com">
                                    <label style="margin-left:90%" for="floatingInput">تواصل</label>
                                </div>


                            </div>

                            <div class="col-2" style="padding-top:2%">

                                <button class="btn btn-primary" style="margin-top:10px" id="sending_text" type="button" disabled>ارسال</button>

                            </div>




                        </div>

                    <?php } ?>
                </div>
            </div>
        </div>



        <!-- THE START OF THE MESSAGING DIV -->

        <div class="tab-pane fade active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <div class="tab-pane fade show active" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="col-7" style="margin-right:10%">

                    <div class="frame" style="background-color: #ffffff;">

                        <div class="messaging-frame">
                            <div class="Title-in-message">
                                <h4 class="title-message"><?php echo $index['Title'] ?></h4>
                            </div>
                            <div class="messaging-box" id="messages">
                                <?php
                                // THE MESSAGE FROM MESSAGE TABLE
                                foreach ($messages as $key => $value) {

                                    if ($_SESSION['EmployeeNum'] === $value['Sender']) { ?>
                                        <div class="row">
                                            <div class="col" style="margin-bottom:15px">
                                                <div class='sent'>
                                                    <?php echo $value['Message'] ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    } else { ?>
                                        <div class="row">
                                            <div class="col" style="margin-bottom:15px">
                                                <div class='recived' id="recieved-bubble">
                                                    <?php echo $value['Message'] ?>
                                                </div>
                                            </div>
                                        </div><?php
                                            }
                                        }
                                                ?>

                            </div>
                            <!--THE BUTTON AND TEXT AREA TO SEND TEXT  -->
                            <!-- INDEX=the whole message so we can send the number and redirect to view -->
                            <!-- ction="<?php //echo base_url() . 'DisplayTicket/sendText/' .  $index['ReportNum'] 
                                        ?>"  -->
                            <div class="row">



                                <div class="col col-10">

                                    <div style="margin-top:17px" class="form-floating mb-3">

                                        <input style="overflow:scroll;" type="text" name="text" id="messages_text_sent" class="form-control texty_sent" <?php if ($index['Status'] == 'مغلق') { ?> disabled <?php } ?> id="floatingInput" placeholder="name@example.com">
                                        <label style="margin-left:90%" for="floatingInput">تواصل</label>
                                    </div>


                                </div>

                                <div class="col-2" style="padding-top:2%">

                                    <button class="btn btn-primary" style="margin-top:10px" id="messages_sending_text" type="button" disabled>ارسال</button>

                                </div>




                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<script>
    // GET THE NEW MESSAGES EVERY MINUTE
    var Refresh_Messages = setInterval(getMessages, 60000);

    $(document).ready(function() {

        // CAPTURE EVENTS IN THE MESSAGES NAV TAB
        $('#messages_text_sent').keyup(function(e) {
            console.log($('#messages_text_sent'));
            //كتب ومارسل
            if ($('#messages_text_sent').val().length != 0 && e.which != 13) {
                $('#messages_sending_text').removeAttr('disabled');


            }
            // ماكتب وارسل 
            else if ($('#messages_text_sent').val().length == 0 && e.which == 13) {
                alert('الرجاء إرفاق رسالة');

            }
            //  كتب وارسل 
            else if ($('#messages_text_sent').val().length != 0 && e.which == 13) {
                $('#messages_sending_text').attr('disabled', false);
                var report = $('#report_num').val()
                var reportInt = parseInt(report);
                var text = $('#messages_text_sent').val();
                $('#messages_text_sent').val('');
                $.ajax({
                    url: "<?php echo base_url() . 'DisplayTicket/sendNewText' ?> ",
                    type: "POST",
                    data: {
                        text: text,
                        reportNum: reportInt
                    },
                    success: getMessages()

                });

            }
            // مارسل وماكتب
            else if ($('#messages_text_sent').val().length == 0 && e.which != 13) {
                $('#messages_sending_text').attr('disabled', true);
            }
        });
        $('#messages_sending_text').click(function() {


            var report = $('#report_num').val()
            var reportInt = parseInt(report);
            var text = $('#text_sent').val();

            $('#messages_text_sent').val('');// TO EMPTY THE INPUT FIELD AFTER SENDING

            $.ajax({
                url: "<?php echo base_url() . 'DisplayTicket/sendNewText' ?> ",
                type: "POST",
                data: {
                    text: text,
                    reportNum: reportInt
                },
                success: getMessages()

            });
        });

        // CAPTURE EVENTS IN THE REPORTS NAV TAB
        $('#sending_text').click(function() {


            var report = $('#report_num').val()
            var reportInt = parseInt(report);
            var text = $('#text_sent').val();

            $('#text_sent').val('');// TO EMPTY THE INPUT FIELD AFTER SENDING

            $.ajax({
                url: "<?php echo base_url() . 'DisplayTicket/sendNewText' ?> ",
                type: "POST",
                data: {
                    text: text,
                    reportNum: reportInt
                },
                success: getMessages()
            });
        });


        $('#text_sent').keyup(function(e) {
            console.log($('#text_sent'));
            //كتب ومارسل
            if ($('#text_sent').val().length != 0 && e.which != 13) {
                $('#sending_text').removeAttr('disabled');


            }
            // ماكتب وارسل 
            else if ($('#text_sent').val().length == 0 && e.which == 13) {
                alert('الرجاء إرفاق رسالة');

            }
            //  كتب وارسل 
            else if ($('#text_sent').val().length != 0 && e.which == 13) {
                $('#sending_text').attr('disabled', false);
                var report = $('#report_num').val()
                var reportInt = parseInt(report);
                var text = $('#text_sent').val();
                $('#text_sent').val('');
                $.ajax({
                    url: "<?php echo base_url() . 'DisplayTicket/sendNewText' ?> ",
                    type: "POST",
                    data: {
                        text: text,
                        reportNum: reportInt
                    },
                    success: getMessages()

                });

            }
            // مارسل وماكتب
            else if ($('#text_sent').val().length == 0 && e.which != 13) {
                $('#sending_text').attr('disabled', true);
            }
        });


    });

    function getMessages() {

        var report = $('#report_num').val()
        var reportInt = parseInt(report);
        $.ajax({
            url: "<?php echo base_url() . 'DisplayTicket/getNewMessages' ?>",
            type: "POST",
            data: {
                reportNum: reportInt
            },
            success: function(src) {
                var data = $.parseJSON(src);
                console.log(data);


                var texts = "";
                $.each(data, function(index, row) {

                    if (row.Sender == <?= $_SESSION['EmployeeNum'] ?>) {

                        texts += " <div class='row'> <div class='col' style='margin-bottom:15px'> <div class='sent'>";
                        texts += row.Message;
                        texts += "</div> </div> </div>"
                    } else {
                        texts += " <div class='row'> <div class='col' style='margin-bottom:15px'> <div class='recived' id='recieved-bubble'>"
                        texts += row.Message;
                        texts += "</div> </div> </div>"
                        texts += "</div>";

                    }

                });

                $('#messages').html(texts);
            }
        })

    }





    // Get the modal
    var modal = document.getElementById("myModal");

    function disable() {
        document.getElementsByClassName('texting-form').disabled = true;

    }

    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = document.getElementById("myImg");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }
</script>