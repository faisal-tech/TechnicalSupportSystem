<div class="container">

    <div class="loginbox">
        <div class="login">
            <?php  echo form_open(base_url('Login/authentication'));   ?>

                <h3 style="color:#fff; padding-top:30px; padding-bottom:39px;">تسجيل الدخول</h3>


                <label class="employee" for="employeeNum">الرقم الوظيفي </label>
                <br>
                <div>

                <input type="text" name="employeeNum" placeholder="&#xf406" style="font-family:FontAwesome; border:0; border-radius: 10px; width: 200px;padding-right: 10px;" value="<?php echo set_value('employeeNum')?>">


                <br>

                <div class="has-validation">

                <label class="password " for="password">الرقم السري </label>
                <input type="password" name="password" placeholder="&#xf023" style=" font-family:FontAwesome; border:0; border-radius: 10px; padding-left:5px; width:200px; padding-right:10px" value="<?php echo set_value('password') ?>"></i>
                </div>
                </div>

                <br>
                
                <div class="flash_data">
                <?php echo validation_errors()?>
                <div class="invalid-feedback">
                <?php echo $this->session->flashdata('msg'); ?>    </div>
               </div>
                <button class="submit-btn" name="submit" type="submit">الدخول</button>
                <input class="reset-btn" type="reset" value="الغاء الآمر">

            </form>

        </div>

    </div>

</div>
<script>
    setInterval(function()
  {
     $('#flash_data').fadeOut('slow');
  }, 3000);
</script>