<style>
    .arrow {

        margin-top: 40px;
    }

    .desc {

        margin-right: 10%;

        padding-top: 4%;

        padding-bottom: 10%;
    }

    #title-label {

        margin-top: 4%;

        margin-bottom: 2%;
    }

    #title {
        display: inline-block;

        margin-top: 4%;

        border-radius: 10px;
        border: none;
        background-color: #E8E8E8;
        padding-right: 1%;
        font-size: 1.2rem;
        width: 50%;
    }

    .con {
        padding-right: 15%;
    }

    #description {

        border-radius: 15px;
        background-color: #E8E8E8;
        border: none;
        padding-right: 1%;
        padding-top: 1%;
        font-size: 1.2rem;

    }

    .image-Preview {
        direction: ltr;
        width: 300px;
        min-height: 100px;

        border: 1px solid #dddddd;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bolder;
        color: #cccccc;
    }

    .imagePreviewImage {
        display: none;
        width: 100%;
    }

    #inpImage {
        margin-top: 5%;
    }

    #description {
        display: inline;
    }

    .image-container {

        margin-top: 25%;

    }

    .send-ticket {
        width: 10%;
        border-radius: 6px;
        margin-right: 40%;
        background-color: #FFFFFF;
    }

    .send-ticket:hover {
        background-color: #DADBDF;
    }

    .cancel-ticket {
        background-color: #FFFFFF;
        width: 10%;
        margin-right: 10px;
        border-radius: 6px;
        border: thin 1px;
        color: #000;
    }

    .cancel-ticket:hover {
        background-color: #DADBDF;
    }

    .buttons {
        margin-bottom: 50px;
    }
</style>

<section>
    <div class="arrow">
        <!-- TO DECIDE TO WHICH DASHBOARD  -->
        <a href="<?php echo base_url() . 'UserDashboard/view' ?>"> <img height="30px" src="<?php echo base_url() . 'images/right-arrow.png' ?>"></a>
    </div>
    <form action="<?php echo base_url(); ?>Ticket/filingComplaint" method="post" enctype="multipart/form-data">

        <div class="row">

            <div class="col-lg-6">
                <div class="desc">


                    <label id="title-label" for="title">الـعـنـوان:</label>
                    <input type="text" id="title" placeholder="ماهي المشكلة" name="title">
                    <br>
                    <textarea name="description" id="description" cols="50" rows="15" placeholder="أخـبـرنـا بـالتـفـاصـيـل"></textarea>
                </div>
            </div>
            <div class="col-lg-6">

                <div class="image-container">
                    <input type="file" name="inpImage" id="inpImage">
                    <div class="image-Preview" id="imagePreview">
                        <img src="" alt="" class="imagePreviewImage">
                        <span class="imagePreview_span">image preview</span>
                    </div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="buttons">
                <input type="submit" class="send-ticket" value="آرسـال">
                <input type="button" class="cancel-ticket" value="الـغاء الآمر">
            </div>
        </div>
    </form>




</section>

<script>
    const inpImage = document.getElementById("inpImage");
    const previewContainer = document.getElementById("imagePreview");
    const previewImage = previewContainer.querySelector(".imagePreviewImage");
    const previewDefaultText = previewContainer.querySelector(".imagePreview_span");

    inpImage.addEventListener("change", function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();

            previewDefaultText.style.display = "none";
            previewImage.style.display = "block";

            reader.addEventListener("load", function() {
                previewImage.setAttribute("src", this.result);
            });
            reader.readAsDataURL(file);
        } else {
            previewDefaultText.style.display = null;
            previewImage.style.display = null;
            previewImage.setAttribute("src", "")
        }
    });
</script>