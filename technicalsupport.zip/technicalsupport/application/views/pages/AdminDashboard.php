<div class="col col-12">

    <section>




        <table id="table_id" class="display" style="margin-bottom: 10%; width:100%">
            <thead>
                <tr>
                    <th>رقم التذكرة</th>
                    <th>العنوان</th>
                    <th>الوصف</th>
                    <th>الحالة</th>
                    <th>النظام</th>
                    <th>المستخدم</th>
                    <th>التاريخ</th>
                </tr>
            </thead>
            <tbody>
               
                <?php foreach ($tickets as $index => $TicketsIndex) { ?>

                    <tr>

                        <td>
                            <a href="<?php echo base_url() ?>DisplayTicket/view/<?php echo $TicketsIndex['ReportNum'] ?>">

                                <?php echo $TicketsIndex['ReportNum']; ?>
                            </a>
                        </td>
                        <td>
                            <?php echo $TicketsIndex['Title']; ?>
                        </td>

                        <td>
                            <?php echo $TicketsIndex['Description']; ?>
                        </td>
                        <td>
                            <?php echo $TicketsIndex['Status']; ?>
                        </td>
                        <td>
                            <?php echo $TicketsIndex['System']; ?>
                        </td>
                        <td>
                            <?php echo $TicketsIndex['ReportUser']; ?>
                        </td>
                        <td>
                            <?php echo $TicketsIndex['date']; ?>
                        </td>

                    </tr>


                <?php };
                ?>
                <!-- </form> -->
            </tbody>
            <tfoot>
                <tr>
                    <th>رقم التذكرة</th>
                    <th>العنوان</th>
                    <th>الوصف</th>
                    <th>الحالة</th>
                    <th>النظام</th>
                    <th>المستخدم</th>
                    <th>التاريخ</th>
                </tr>
            </tfoot>
        </table>
        <br>



    </section>
</div>

</div>
</div>


<script>
    
    $(document).ready(function() {
        $('#table_id').DataTable();
    });
    
</script>