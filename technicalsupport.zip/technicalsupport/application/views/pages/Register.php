<section>
    <div class="container-fluid">
        <div class="registration">
            <div class="row NewRegistration">
                <div class="col-12"></div>
            </div>
            <form action="<?php echo base_url() . 'Register/register' ?>" method="POST">
                <div class="row">

                    <div class="col-md-6 col-sm-12 ">
                    <?php echo form_error('FirstName' ,'<div class="invalid-feedback">', '</div>') ?>
                        <label for="FirstName" class='form-label'>الأسم الأول:</label>
                        <input type="text" class="form-control" name="FirstName" id="validationCustom01" placeholder="First name" aria-label="Firstname">
                        <?php echo form_error('FirstName','<p style="	color:#e40000">','</p>'); ?>
                    </div>



                    <div class="col-md-6 col-sm-12">
                        <label for="LastName" class='form-label'>الأسم الأخير:</label>
                        

                        <input type="text" class="form-control" name="LastName" id="validationCustom02" placeholder="Last name" aria-label="Lastname" >

                           <p class="validation-err"> 
                               <?php echo form_error('LastName','<p style="	color:#e40000">','</p>'); ?>
                            </p>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        
                        <label for="department" class="form-label">القسم:</label>
                        <select name="department" id="" aria-label="Defult" class="form-select" >
                            <option selected disabled>اختر..</option>
                            <option value="Human Resources">Human Resources</option>
                            <option value="Finance">Finance</option>
                            <option value="Managment">Managment</option>
                            <option value="Employee Affair">Employee Affair</option>
                        </select>
                        <?php echo form_error('department','<p style="	color:#e40000">','</p>'); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <label for="email" class="form-label">البريد الالكتروني:</label>
                        
                        <div class="form-floating mb-3">
                            <input type="email" name="email" class="form-control" id="floatingInput1 validationCustom03" placeholder="name@example.com" >
                            <label for="floatingInput">name@example.com</label>
                            <?php echo form_error('email','<p style="	color:#e40000">','</p>'); ?>

                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <label for="confirm-email" class="form-label">تأكيد البريد الالكتروني:</label>
                    
                        <div class="form-floating mb-3">
                            <input type="email" name="confirm-email" class="form-control" id="floatingInput2" placeholder="name@example.com">
                            <label for="floatingInput">name@example.com</label>
                            <?php echo form_error('confirm-email','<p style="	color:#e40000">','</p>'); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <label for="" class="form-label">كلمة المرور:</label>
                        <div class="form-floating">
                        
                            <input type="password" name="password" class="form-control" id="floatingPassword1" placeholder="Password" >
                            <?php echo form_error('password','<p style="color:#e40000;font-size:small;">','</p>'); ?>
                            <label for="floatingPassword">Password</label>
                            
                        </div>
                    </div>
                    <div class="col">
                        <label for="" class="form-label">تأكيد كلمة المرور:</label>
                        <div class="form-floating">
                            <input type="password" name="confirm-password" class="form-control" id="floatingPassword2" placeholder="Password" >
                            <label for="floatingPassword">Password</label>
                            <?php echo form_error('confirm-password','<p style="	color:#e40000">','</p>'); ?>

                        </div>
                    </div>
                </div>

                <div class="row buttons">
                    <div class="col" style="margin-right:40%">
                        <input type="submit" value="التسجيل" style="margin-left:10px" class="register">
                        <input type="reset" value="الغاء الآمر" class="cancel">
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<script>
    
</script>