<?php

class UserDashboard extends CI_Controller
{

    public function __construct()
    {

        parent::__construct();
        $this->load->model('Ticket_Model');
        $this->load->model('Messages_Model');
        $this->load->model('Users');
    }

    public function view()
    {

        $user = $_SESSION['EmployeeNum'];
        $data['tickets'] = $this->Ticket_Model->getUserTickets($user);
        // die(var_dump($data));
        // $data['messages'] = $this->Messages_Model->getUserMessages($user);
        // foreach($data['messages'] as $x => $y){
        //     // echo $y['Admin'];
        // }
        // $EmployeeNum= $y['Admin'];
        $data['tickets'] = $this->Ticket_Model->getUserTickets($user);
        // $data['Name'] = $this->Users->getFullName($EmployeeNum);
        // die(var_dump($data));
        $this->load->view('templates/header');
        $this->load->view('templates/Aside');
        $this->load->view('pages/UserDashboard', $data);
        $this->load->view('templates/footer');
    }
}
