<?php

class Ticket extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('Ticket_Model');
    }
    public function view()
    {
        $this->load->view('templates/header');
        $this->load->view('pages/Ticket', array('error' => ' '));
        $this->load->view('templates/footer');
    }

    public function filingComplaint()
    {
        // die(var_dump($_FILES['inpImage']));
        // die (var_dump(explode('/',$_FILES['inpImage']['type'])));
        // die(var_dump($_FILES['inpImage']['type']));
        $imgType=$_FILES['inpImage']['type'];
        $type =explode('/',$imgType);
        // static $count=1;
        // die($type[1]);
        $img=$_FILES['inpImage']['name']=time().'UserImage'.'.'.$type[1];
        // $img=$_FILES;
        // die(var_dump($img));
        
        // $count++;
        
        $config['upload_path']          = './Uploaded_Image/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['file_name']            = $img;
        $config['max_size']             = 400;
        $config['max_width']            = 0;
        $config['max_height']           = 0;

        $this->upload->initialize($config);
        if (!$this->upload->do_upload('inpImage')) {
            $error = array('error' => $this->upload->display_errors());

            die(var_dump($error));
        } else {
            $title = $this->input->post("title");
            $disc = $this->input->post("description");
            $user = $this->session->EmployeeNum;
            $department = $this->session->Department;
            // die($img);

            $this->Ticket_Model->sendComplaint($user, $title, $disc, $img, $department);

            $data = array('upload_data' => $this->upload->data());
            
    
    
                redirect('UserDashboard/view');
                
        }
        
    }
}
