<?php

class Register extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Users');
    }

    public function view()
    {
        $a = 5;
        $this->load->view('templates/header');
        $this->load->view('pages/Register');
        $this->load->view('templates/footer');
    }

    public function register()
    {

        $this->form_validation->set_rules('FirstName', 'First Name', 'trim|min_length[3]|required');
        $this->form_validation->set_rules('LastName', 'Last Name', 'trim|min_length[3]|required');

        $this->form_validation->set_rules('department', 'Department', 'required');

        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('confirm-email', 'Email', 'trim|required|matches[email]|valid_email');

        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('confirm-password', 'Password', 'trim|required|min_length[8]|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            //SHOW AN ERROR TO USERS
            $this->load->view('templates/header');
            $this->load->view('pages/Register');
            $this->load->view('templates/footer');
        } else {

            //REGISTER THEM 
            $FirstName = $this->input->post('FirstName');
            $LastName = $this->input->post('LastName');
            $department = $this->input->post('department');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            // $PasswordConf = $this->input->post('confirm-password');
            
            if($department !=='IT'){
                $level=2;
            }
            else{
                $level=1;
            }

            $this->Users->register($FirstName, $LastName, $department, $email, $password,$level);
            redirect('Login/LoginPage');
        }
    }
}
