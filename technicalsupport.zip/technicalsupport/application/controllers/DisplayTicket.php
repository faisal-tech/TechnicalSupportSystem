<?php

class DisplayTicket extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Ticket_Model');
        $this->load->model('Messages_Model');
        $this->load->model('Users');
    }
    public function view($report)
    {
        $data['report'] = $this->Ticket_Model->getReport($report);
        $data['messages'] = $this->Messages_Model->getMessages($report);
        // foreach ($data['messages'] as $key => $value) {
        // }
        // die(var_dump($value));
        $this->load->view('templates/header');
        $this->load->view('pages/DisplayTicket', $data);
        $this->load->view('templates/footer');
        // die(var_dump($data['messages']));
    }

    public function message($number)
    {

        $message = $this->input->post('admin-message');
        $Admin = $_SESSION['EmployeeNum'];
        $report = $number;
        $reportUser = $this->Reports->getUser($number);
        // die(var_dump($user));
        $user = $reportUser['ReportUser'];
        $this->Messages_Model->sendMessage($message, $report, $Admin, $user);
        redirect('DisplayTicket/view/' . $report);
    }

    public function sendText($report)
    {
        $sender = $_SESSION['EmployeeNum'];
        $message = $this->input->post('text');
        $this->Messages_Model->sendMessage($message, $report, $sender);
        redirect(base_url() . 'DisplayTicket/view/' . $report);
    }

    //SEND TEXT WITHOUT REFRISHING THE PAGE  
    public function sendNewText()
    {
        $decdeText = urldecode($_POST['text']);
        $report = $_POST['reportNum'];
        $sender = $_SESSION['EmployeeNum'];
        $this->Messages_Model->sendMessage($decdeText, $report, $sender);
    }

    //ASSIGN ADMIN BASES TO A REPORT 
    public function assignAdmin($report)
    {
        $techsupport = $_SESSION['EmployeeNum'];
        $this->Ticket_Model->assignAdmin($report, $techsupport);
        redirect('DisplayTicket/view/' . $report);
    }



    public function changeStatus($report)
    {
        $this->Ticket_Model->changeStatus($report);
        redirect('AdminDashboard/view');
    }

    // UPDATE MESSAGES BASED ON REPORT NUMBER
    public function getNewMessages()
    {
        $report= $_POST['reportNum'];
        $x =$this->Messages_Model->getMessages($report);
        echo json_encode($x);
        
        
    }
}
