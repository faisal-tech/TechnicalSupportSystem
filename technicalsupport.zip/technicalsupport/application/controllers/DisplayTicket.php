<?php

class DisplayTicket extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Ticket_Model');
        $this->load->model('Messages_Model');
        $this->load->model('Users');
    }
    public function view($report)
    {
        $data['report'] = $this->Ticket_Model->getReport($report);
        $data['messages'] = $this->Messages_Model->getMessages($report);
        // foreach ($data['messages'] as $key => $value) {
        // }
        // die(var_dump($value));
        $this->load->view('templates/header');
        $this->load->view('pages/DisplayTicket', $data);
        $this->load->view('templates/footer');
        // die(var_dump($data['messages']));
    }

    public function message($number)
    {

        // if()

        $message = $this->input->post('admin-message');
        $Admin = $_SESSION['EmployeeNum'];
        $report = $number;
        $reportUser = $this->Reports->getUser($number);
        // die(var_dump($user));
        $user = $reportUser['ReportUser'];
        $this->Messages_Model->sendMessage($message, $report, $Admin, $user);
        redirect('DisplayTicket/view/' . $report);
    }

    public function sendText($report)
    {

        $sender = $_SESSION['EmployeeNum'];
        $message = $this->input->post('text');
        $this->Messages_Model->sendMessage($message,$report ,$sender);
        redirect(base_url() . 'DisplayTicket/view/' . $report);
    }
    public function assignAdmin($report){
        $techsupport= $_SESSION['EmployeeNum'];

        $this->Ticket_Model->assignAdmin($report,$techsupport);
        redirect('DisplayTicket/view/'.$report);

    }
    public function changeStatus($report){
        $this->Ticket_Model->changeStatus($report);
        redirect('AdminDashboard/view');
    }
}
