<?php

class AdminDashboard extends CI_Controller{


    function __construct(){
        parent::__construct();
        $this->load->model('Ticket_Model');
        $this->load->model('Messages_Model');        
    }
    public function view(){
        $data['tickets']=$this->Ticket_Model->displayAllTickets();
        $data['messages']=$this->Messages_Model->getAllMessages();
        // die(var_dump($data['messages']));
        $this->load->view('templates/header');
        $this->load->view('pages/AdminDashboard',$data);
        $this->load->view('templates/footer');
        // die(var_dump($_SESSION));
    }


    
}