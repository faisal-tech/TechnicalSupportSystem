<?php

class Messaging extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Messages_Model');
        $this->load->model('Communications');

    }

    public function view($MessageNum)
    {   
        // die(var_dump($message));
        $first=$this->Messages_Model->getFirstText($MessageNum);
        // die(var_dump($first));
        $rest =$this->Communications->getText($MessageNum);
        // die(var_dump($rest));
        $data['first']=$first;
        $data['rest']=$rest;
        $data['message']=$MessageNum;
        // $data['title']=$this->
        $this->load->view('templates/header');
        $this->load->view('templates/Aside');
        $this->load->view('pages/Messaging',$data);
        $this->load->view('templates/footer');
    }

    public function sendText($message){

        $text= $this->input->post('text');
        $sender=$_SESSION['EmployeeNum'];
        $this->Communications->sendText($text,$message,$sender);
        
    }

}
