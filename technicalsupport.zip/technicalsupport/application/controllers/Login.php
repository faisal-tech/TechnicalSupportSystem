<?php

class Login extends CI_Controller{


    public function __construct(){

        parent::__construct();
        $this->load->model('Users');
        // $this->load->helper(array('form', 'url'));
        $this->load->database();
        $this->load->model('Users');
        //$this->LoginPage();
        // die(var_dump($_SESSION));
            
        if(isset($_SESSION['login']) && $_SESSION['login'] ==true){
            if($_SESSION['PrivilegeLevel']=='1'){

            redirect("AdminDashboard/view");
        }else  if ($_SESSION['PrivilegeLevel']=='2'){
            redirect("UserDashboard/view");
        }
    }
}
     
    

    public function LoginPage(){

        // $this->load->helper('url');
        $this->load->view('templates/header');
        $this->load->view('pages/Login');
        $this->load->view('templates/footer');
      
    }
    // takes form inputs and authorize  
    public function authentication(){
        
        $this->form_validation->set_rules('employeeNum','EmployeeNumber','required|length[8]');
        $this->form_validation->set_rules('password','password','required|max_length[16]|min_length[8]');
        
        //post user unput
        $empNum=$this->input->post('employeeNum');
        $pwd=$this->input->post('password');
        if ($this->form_validation->run() == true)
                {
                        redirect('Login/LoginPage');
                }
                else{


        

        //call query method
        $user=$this->empNumAuth($empNum, $pwd);
        if($user) {
            if($user['PrivilegeLevel']==='1'){
                $user['login']=true;
                //SETING SESSION and display VIEW
                $this->session->set_userdata($user);
                // die(var_dump($user));

                redirect('AdminDashboard/view');
            }
            else 
            if($user['PrivilegeLevel']==='2') { 
                $user['login']=true;
                //SETING SESSION and display VIEW
                $this->session->set_userdata($user);
                redirect('UserDashboard/view');
        }

        }

        else {
            $this->session->set_flashdata('msg','الرقم الوظيفي او رمز الدخول خاطئ');
            redirect('Login/LoginPage');
        }
    }}

    public function empNumAuth($empnum,$pwd){

        $res=$this->Users->numResult($empnum,$pwd);

        return $res;
        
        
    }

    
   
}
