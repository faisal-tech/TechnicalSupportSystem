<?php

class UserInfo extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->model('Ticket_Model');
        
    }
    public function view(){
        $num=$_SESSION['EmployeeNum'];
        $data['numTicket']=$this->Ticket_Model->getNumOfTicket($num);
        
        $this->load->view('templates/header');
        $this->load->view('pages/UserInfo',$data);
        $this->load->view('templates/footer');
    }

    public function signOut(){
        $this->session->sess_destroy();
        redirect("Login/LoginPage");
    }

   



}