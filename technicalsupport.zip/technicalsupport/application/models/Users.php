<?php

class Users extends CI_Model
{

    public function numResult($num, $pwd)
    {

        $query = $this->db->query("SELECT * FROM Users WHERE EmployeeNum='$num' and Password='$pwd'");
        $row = $query->row_array();

        if (isset($row)) {

            return $row;
        } else {
            return false;
        }
    }

    // GET ADMIN OR USER FULL NAME BASE ON THE EMPLOYEE NUMBER  
    public function  getFullName($EmployeeNum)
    {
        $query = $this->db->query("SELECT FName ,LName FROM Users where EmployeeNum='$EmployeeNum'");
        $row = $query->result_array();
        // die(var_dump($row));
        foreach ($row as $key => $index) {
        }
        return $index['FName'] . " " . $index['LName'];
    }

    // Register New USERS
    public function register($FirstName, $LastName, $department, $email, $password,$level)
    {
       
        
        $data=array(
            'FName'=>$FirstName,
            'LName'=>$LastName,
            'Department'=>$department,
            'Email'=>$email,
            'Password'=>$password,
            'PrivilegeLevel'=>$level

        );
        $this->db->insert('Users',$data);
    }
}
