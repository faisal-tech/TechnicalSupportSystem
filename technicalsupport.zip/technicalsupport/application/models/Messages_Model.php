<?php

class Messages_Model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Reports');
    }

    public function sendMessage($message, $report, $sender)
    {
        $query = $this->db->query("INSERT INTO Messages (ReportNum,Sender,Message) VALUES ('$report','$sender','$message');");
        if(isset($query)){
            $this->load->model('Ticket_Model');
            $this->Ticket_Model->assignAdmin($report,$sender);
        }
    }
    //GET ALL MESSAGES BASED ON THE REPORT NUMBER
    public function getMessages($ticketNum)
    {
        $query = $this->db->query("SELECT * FROM Messages WHERE ReportNum ='$ticketNum' order by date");
        return $row = $query->result_array();
    }
    // GET ALL MESSAGES FOR THE Admin DASHBOARD
    public function getAllMessages()
    {
        $query = $this->db->query("SELECT * FROM Messages");
        return $row = $query->result_array();
    }


    public function getUserMessages($userNum)
    {
        $query = $this->db->query("SELECT * FROM Messages WHERE user='$userNum'");
        return $row = $query->result_array();
    }



    //GET FIRST MESSAGE FOR THE TEXTING PAGE
    public function getFirstText($message)
    {
        $query = $this->db->query("SELECT * FROM Messages WHERE MessageNum ='$message'");
        return $row = $query->result_array();
    }

    //CHECK IF THERE IS A MESSSAGE HAS BEEN CREATED BY AN ADMIN
    //TO A TICKET SO WE CAN ASSIGN A TICKET TO A USER
    public function assignAdmin($ReportNum)
    {
        $query = $this->db->query("SELECT Admin from Messages where ReportNum ='$ReportNum' ");
        return $row =$query->result_array();
    }
}
