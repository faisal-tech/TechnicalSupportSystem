<?php

class Reports extends CI_Model
{

    //GET THE USER OF A REPORT BASED ON THE REPORT NUMBER
    public function getUser($report)
    {
        $query = $this->db->query("SELECT ReportUser FROM Report WHERE ReportNum = '$report' ");
        return $row = $query->row_array();
    }

    //GET THE TITLLE OF A SPECIFIC REPORT BASED ON A REPORT NUMBER
    public function getTitle($ReportNum)
    {
        $query = $this->db->query("SELECT Title FROM Report WHERE ReportNum ='$ReportNum'");
        return $row = $query->row_array();
        // foreach($row as $index=>$value){
        //     return $index['Title'];
        // }
        
    }

    //GET THE DECRIPTION BASED ON THE REPORT NUM
    public function getDescription($ReportNum)
    {
    }
}
