<?php

class Ticket_Model extends CI_Model{


    //WHEN THE USER WILL REPORT AN ISSUE THIS QUERY WILL BE USED
    public function sendComplaint($user,$title,$disc,$img,$department,){
        
        $query= $this->db->query("INSERT INTO Report (ReportUser,System,Description,Title,image)
                                                    VALUES('$user','$department','$disc','$title','$img')");
    }


    //DISPLAY ALL TICKETS TO THE DASHBOARD
    public function displayAllTickets(){
        
        $sql=$this->db->query("SELECT * FROM Report");
        return $sql->result_array();
    }


    //DISPLAY A TICKET WHEN THE ADMIN PRESS ON A TICKET 
    public function getReport($report){
        $query= $this->db->query("SELECT * FROM Report WHERE ReportNum ='$report'");
        return $row = $query->result_array();
    
    }

    
    public function getNumOfTicket($reporter){
        
        $query=$this->db->query("SELECT COUNT(ReportUser)
        FROM Report
        WHERE ReportUser='$reporter'");
        return $query->row_array();
        
    } 
    public function getUserTickets($user){

        $query=$this->db->query("SELECT * FROM Report WHERE ReportUser='$user'");

        return $row=$query->result_array();
    }

    //ASSIGN A ADMIN TO A TICKET
    public function assignAdmin($ReportNum,$ReportAdmin){

        $query =$this->db->query("UPDATE Report SET ReportAdmin ='$ReportAdmin'  WHERE ReportNum = '$ReportNum';");
    }

    public function getTitle(){
        
    }
}