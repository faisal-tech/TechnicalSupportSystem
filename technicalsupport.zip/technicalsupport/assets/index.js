
function sendAMessage() {

    var text= $('#text');
    var encodeText = encodeURIComponent(text.value);

    $(document).ready(function(){
        $.post("<?php echo base_url().'DisplayTicket/sendNewText/'. $index['ReportNum'].'/' ?>", encodeText, function(){
            console.log('success');
        });
        $('.sent').load("<?php echo base_url() . 'DisplayTicket/sendNewText/' . $index['ReportNum'] ?>/" + encodeText);
})

    // var text = document.getElementById('text');

    // var encodeText = encodeURIComponent(text.value)
    // var request = new XMLHttpRequest();
    // request.onreadystatechange = function() {
    //     if (this.readyState == 4 && this.status == 200) {
    //         console.log('sent');
    //     }
    // };
    // request.open('POST',
    //     "<?php //echo base_url() . 'DisplayTicket/sendNewText/' . $index['ReportNum'] ?>/" + encodeText,
    //     true);
    // request.send();
    // getMessages();
}

function getMessages(){
    
}

// Get the modal
var modal = document.getElementById("myModal");

function disable() {
    document.getElementsByClassName('texting-form').disabled = true;

}

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function() {
    modal.style.display = "block";
    modalImg.src = this.src;
    captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}
